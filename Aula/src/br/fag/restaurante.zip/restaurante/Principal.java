package br.fag.restaurante;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Stack;

public class Principal {
	
	private static Random randomizar = new Random();
	
	private static EstruturaQualquer<EstruturaCardapio> cardapio = Cardapio.gerarCardapio();
	private static EstruturaQualquer<EstruturaBebida> bebidas = Bebidas.gerarBebidas();
	private static EstruturaQualquer<EstruturaChocolate> chocolates = Chocolates.gerarChocolates();
	private static EstruturaQualquer<EstruturaCliente> clientes = Clientes. gerarClientes();
	
	private static Stack<EstruturaChocolate> pilhaChocolates = new Stack<EstruturaChocolate>();
	private static ArrayList<EstruturaCliente> clientesRestaurante = new ArrayList<EstruturaCliente>();
	private static Queue<EstruturaCliente> filaCaixa = new LinkedList<EstruturaCliente>();
	
	public static void main(String[] args) {
		
		
		gerarPilhaChocolates();
		adicionarCliente();
		
		irParaPagamento();
		finalizarPagamento();
		
		exibirFilaCaixa();
		exibirPilhaChocolates();
//		exibirClientesRestaurante();
		
		
//		System.out.println(cardapio.getItem(3).getDescricao());
//		System.out.println(bebidas.getItem(2).getNome());
//		System.out.println(chocolates.getItem(5).getNome());
//		System.out.println(clientes.getItem(15).getNome());
		
			
		
		
	}

	private static void finalizarPagamento() {
		while (!filaCaixa.isEmpty()) {
			int idChocolate = pilhaChocolates.pop().getId();
			filaCaixa.peek().setIdChocolate(idChocolate);
			int idBebida = filaCaixa.peek().getIdBebida();
			int idCardapio = filaCaixa.peek().getIdCardapio();
			String nome = filaCaixa.peek().getNome();
			String prato = cardapio.getItem(idCardapio).getNome();
			String bebida = bebidas.getItem(idBebida).getNome();
			String chocolate = chocolates.getItem(idChocolate).getNome();
			double conta = cardapio.getItem(idCardapio).getPreco()+bebidas.getItem(idBebida).getPreco();
			Apoio.exibirMensagem(nome+" comeu um "+prato+"\nbebeu "+bebida+"\nrecebeu um "+chocolate+"\ne pagou R$ "+conta);
			filaCaixa.remove();
		}
		
	}

	private static void exibirFilaCaixa() {
		int i =1;
		
		for (EstruturaCliente clienteProximo : filaCaixa) {			
			Apoio.exibirMensagem("Número "+i+" da Fila: "+clienteProximo.getNome());	
			i++;
		}	
		
	}

	private static void irParaPagamento() {
		EstruturaCliente clienteProximo = new EstruturaCliente();
		
		while (!clientesRestaurante.isEmpty()) {
			int idCliente = randomizar.nextInt(clientesRestaurante.size());
			clienteProximo = clientesRestaurante.get(idCliente);
			clientesRestaurante.remove(idCliente);
			filaCaixa.add(clienteProximo);			
		}
		
	}

	private static void fazerPedido(int i) {
		
		int idC = randomizar.nextInt(70)/10;
		int idB = randomizar.nextInt(90)/10;
		
		clientesRestaurante.get(i).setIdCardapio(idC);
		clientesRestaurante.get(i).setIdBebida(idB);	
		
	}

	private static void adicionarCliente() {
		
		for (int i = 0; i < 20; i++) {
			clientesRestaurante.add(clientes.getItem(i));			
			fazerPedido(i);
		}		
		
	}

	private static void exibirPilhaChocolates() {
		int i=0;
		for (EstruturaChocolate chocolate : pilhaChocolates) {
			Apoio.exibirMensagem("Chocolate "+ (pilhaChocolates.size()-i) + ": "+chocolate.getNome());
			i++;
		}
	}

	private static void gerarPilhaChocolates() {		
		if (pilhaChocolates.empty()) {
			int chocolate=0;
			while(pilhaChocolates.size()<30) {
				pilhaChocolates.push(chocolates.getItem(chocolate));
				if (chocolate == 8) {
					chocolate = 0;
				}else {
					chocolate++;					
				}
			}
		}		
	}
}
