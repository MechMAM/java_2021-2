package br.fag.lista3;

import java.util.Scanner;

public class Dados {
	
	private static Scanner entrada = new Scanner(System.in);
	
	public static int obterDadosInteiros(String mensagem) {
		System.out.println(mensagem);
		return entrada.nextInt();		
	}
	
	public static String obterDadosString(String mensagem) {
		System.out.println(mensagem);
		return entrada.next();		
	}
	
	public static float obterDadosFloat(String mensagem) {
		System.out.println(mensagem);
		return entrada.nextFloat();		
	}
	
	public static double obterDadosDouble(String mensagem) {
		System.out.println(mensagem);
		return entrada.nextDouble();		
	}
	
	public static void exibirMensagem(String mensagem) {
		System.out.println(mensagem);
	}

}
