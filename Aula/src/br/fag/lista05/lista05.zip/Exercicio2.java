package br.fag.lista05;

import br.fag.listasorteio.Dados;

public class Exercicio2 {
	
	
	public static void main(String[] args) {
		int tamanho = MetodosApoio.obterDadosInteiros("Digite o tamanho do vetor");	
		int[] vetorAleatorio = MetodosApoio.gerarVetorAleatorio(tamanho);
		MetodosApoio.exibirVetor(vetorAleatorio);
		
	}

}
