package br.fag.aula08;

public class Aula {

}

/* Matriz e vetores são variáveis homogêneas, não aceitam outros tipos de dados além do declarado
 * trabalhar com registros e arquivos
 * 
 * 
 */
