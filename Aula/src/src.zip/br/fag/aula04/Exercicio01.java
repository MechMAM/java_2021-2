package br.fag.aula04;

public class Exercicio01 {
	public static void main(String[] args) {
		criarSequencia();
		//exibirResultado();
		
	}

	private static void criarSequencia() {
		for (int i = 0; i < 50; i++) {	
			System.out.println(i+1);
		}		
	}	
}
